<?php 
global $smof_data;
if( !isset($data) ){
	$data = $smof_data;
}

$data = ftc_array_atts(
			array(
				/* FONTS */
				'ftc_body_font_enable_google_font'					=> 1
				,'ftc_body_font_family'								=> "Arial"
				,'ftc_body_font_google'								=> "Roboto Condensed"
				
				,'ftc_secondary_body_font_enable_google_font'		=> 1
				,'ftc_secondary_body_font_family'					=> "Arial"
				,'ftc_secondary_body_font_google'					=> "PT Sans"
				
				/* COLORS */
				,'ftc_primary_color'									=> "#a1b4a0"

				,'ftc_secondary_color'								=> "#444444"
				
                                ,'ftc_body_background_color'								=> "#ffffff"
				/* RESPONSIVE */
				,'ftc_responsive'									=> 1
				,'ftc_layout_fullwidth'								=> 0
				,'ftc_enable_rtl'									=> 0
				
				/* FONT SIZE */
				/* Body */
				,'ftc_font_size_body'								=> 13
				,'ftc_line_height_body'								=> 24
				
				/* Custom CSS */
				,'ftc_custom_css_code'								=> ''
		), $data);		
		
$data = apply_filters('ftc_custom_style_data', $data);

extract( $data );


if( $smof_data['ftc_body_font_enable_google_font'] ){
if( isset($_GET['color']) ){
 $ftc_body_font = $data['ftc_body_font_google'];
}
else{
    $ftc_body_font  = $smof_data['ftc_body_font_google']['font-family'];
}
}

else{
    if( isset($_GET['color']) ){
 $ftc_body_font = $data['ftc_body_font_google'];
} else {
 $ftc_body_font = $data['ftc_body_font_family'];
}
}

if( $smof_data['ftc_secondary_body_font_enable_google_font'] ){
if( isset($_GET['color']) ){
    $ftc_secondary_body_font    = $data['ftc_secondary_body_font_google'];
}
else{
 $ftc_secondary_body_font = $smof_data['ftc_secondary_body_font_google']['font-family'];
}
}
else{
    if( isset($_GET['color']) ){
    $ftc_secondary_body_font    = $data['ftc_secondary_body_font_google'];
}  else {
    $ftc_secondary_body_font    = $data['ftc_secondary_body_font_family'];
}
}
?>
	
	/*
	1. FONT FAMILY
	2. GENERAL COLORS
	*/
	
	
	/* ============= 1. FONT FAMILY ============== */
	
        html, 
	    body,
        .widget-title.heading-title,.subscribe-email .button.button-secondary,
        #mega_main_menu.primary ul li .mega_dropdown > li.sub-style > .item_link .link_text,
        footer#colophon .ftc-footer .widget-title,
        .feedburner h2.widgettitle,
        .ftc-tiny-cart-wrapper .cart-control,
        p.heading-banner,
        .vc_btn3.vc_btn3-color-purple,
        .vc_btn3.vc_btn3-color-purple.vc_btn3-style-flat,
        .cart-number  span.text-cart,
        .off-can-vas-inner .woocommerce.widget_shopping_cart .total strong,
        .off-can-vas-inner p.woocommerce-mini-cart__buttons.buttons > a.button.wc-forward
	{
		font-family: <?php echo esc_html($ftc_body_font) ?>;
	}
	
	    #mega_main_menu.primary ul li .mega_dropdown > li.sub-style > ul.mega_dropdown,
        #mega_main_menu li.multicolumn_dropdown > .mega_dropdown > li .mega_dropdown > li,
        #mega_main_menu.primary ul li .mega_dropdown > li > .item_link .link_text,
        .info-open,
        .info-phone,
        .my-account-wrapper .account-control > a,
        .my-account-wrapper,
        .my-wishlist-wrapper *,
        .dropdown-menu span > span,
        body p,
        .wishlist-empty,
        div.product .social-sharing li a,
        .ftc-search-by-category form,
        .shopping-cart-wrapper,
        .product-label,
        .item-description .heading-title,
        .item-description .price,
        .testimonial-content .content,
        .testimonial-content .byline,
        .widget-container ul.product-categories ul.children li a,
        .widget-container:not(.ftc-product-categories-widget):not(.widget_product_categories):not(.ftc-products-widget) :not(.widget-title),
        .ftc-products-category-tabs-block ul.tabs li span.title,
        .woocommerce-pagination,
        .woocommerce-result-count,
        .woocommerce .products.list .product h3.product-name > a,
        .woocommerce-page .products.list .product h3.product-name > a,
        .woocommerce .products.list .product .price .amount,
        .woocommerce-page .products.list .product .price .amount,
        .products.list .meta-short-des.list,
        div.product .single_variation_wrap .amount,
        div.product div[itemprop="offers"] .price .amount,
        .orderby-title,
        .blogs .excerpt,
        .blog .entry-info .entry-summary .short-content,
        .single-post .entry-ingfo .entry-summary .short-content,
        .single-post article .post-info .info-category,
        .single-post article .post-info .info-category,
        #comments .comments-title,
        #comments .comment-metadata a,
        .post-navigation .nav-previous,
        .post-navigation .nav-next,
        .woocommerce div.product .product_title,
        .woocommerce-review-link,
        .feature-excerpt,
        .woocommerce div.product p.stock,
        .woocommerce div.product .summary div[itemprop="description"],
        .woocommerce div.product p.price,
        .woocommerce div.product .woocommerce-tabs .panel,
        .woocommerce div.product form.cart .group_table td.label,
        .woocommerce div.product form.cart .group_table td.price,
        footer,
        footer a,
        .blogs article .effect-thumbnail:before,
        .blogs article a.gallery .owl-item:after,
        .trending-product h2:before, .hot-product h2:before, .picture h2:before, .blog-home h2:before,
        .woocommerce ul.cart_list li a,
        .woocommerce ul.product_list_widget li a,
        .blogs .post-info .date-time,
        .blogs .post-info .author,
        .blogs .post-info .comment-count,
        .woocommerce .woocommerce-ordering .orderby li,
        .woocommerce-page .woocommerce-ordering .orderby li, 
        .shopping-cart-wrapper .dropdown-container,
        .woocommerce div.product div.summary p.cart a,
        .woocommerce div.product form.cart .button,
        .contact_info_map .info_contact .info_column,
        .woocommerce table.shop_table td a,
        .woocommerce table.shop_table td span,
        .search-wrapper .ajax-search-content input[type="text"],
        .post-info .entry-summary
	{
		font-family: <?php echo esc_html($ftc_secondary_body_font) ?>;
	}
	    body,
        .site-footer,
        .woocommerce div.product form.cart .group_table td.label,
        .woocommerce .product .product-label span,
        .item-description .meta_info .vc-button.wishlist a, .item-description .meta_info .vc-button.compare a,
        ul.product_list_widget li > a, h3.product-name > a,
        h3.product-name, 
        .single-navigation a .product-info span,
        .info-company li i,
        .social-icons .ftc-tooltip:before,
        .widget-container ul.product-categories ul.children li,
        .tagcloud a,
        .product-thumbnails .owl-nav > div:before,
        div.product .summary .yith-wcwl-add-to-wishlist a:before,
        .pp_woocommerce div.product .summary .compare:before,
        .woocommerce div.product .summary .compare:before,
        .woocommerce-page div.product .summary .compare:before,
        .woocommerce #content div.product .summary .compare:before,
        .woocommerce-page #content div.product .summary .compare:before,
        .woocommerce div.product form.cart .variations label,
        .woocommerce-page div.product form.cart .variations label,
        .pp_woocommerce div.product form.cart .variations label,
        .ftc-products-category-tabs-block ul.tabs li span.title,
        blockquote,
        .ftc-milestone h3.subject,
        .woocommerce .widget_price_filter .price_slider_amount,
        .wishlist-empty,
        .woocommerce div.product form.cart .button,
        .woocommerce table.wishlist_table
        {
                font-size: <?php echo esc_html($ftc_font_size_body) ?>px;
        }
	/* ========== 2. GENERAL COLORS ========== */
        /* ========== Primary color ========== */
	
        .header-language:hover li .lang_sel_sel,
        .woocommerce a.remove:hover,
        .dropdown-container .dropdown-footer > a.button.view-cart:hover,
        .my-wishlist-wrapper a:hover,
        .header-currency .wcml_currency_switcher ul li:hover,
        .dropdown-menu span:hover,
        body.wpb-js-composer .vc_general.vc_tta-tabs .vc_tta-tab.vc_active > a,
        body.wpb-js-composer .vc_general.vc_tta-tabs .vc_tta-tab > a:hover,
        .woocommerce .products .product .price,
        .woocommerce div.product p.price,
        .woocommerce div.product span.price,
        .woocommerce .products .star-rating,
        .woocommerce-page .products .star-rating,
        .star-rating:before,
        div.product div[itemprop="offers"] .price .amount,
        div.product .single_variation_wrap .amount,
        .pp_woocommerce .star-rating:before,
        .woocommerce .star-rating:before,
        .woocommerce-page .star-rating:before,
        .woocommerce-product-rating .star-rating span,
        ins .amount,
        .ftc-wg-meta .price ins,
        .ftc-wg-meta .star-rating,
        .ul-style.circle li:before,
        .woocommerce form .form-row .required,
        .blogs .comment-count i,
        .blog .comment-count i,
        .single-post .comment-count i,
        .single-post article .post-info .info-category,
        .single-post article .post-info .info-category .cat-links a,
        .single-post article .post-info .info-category .vcard.author a,
        .breadcrumb-title .breadcrumbs-container,
        .breadcrumb-title .breadcrumbs-container span.current,
        .breadcrumb-title .breadcrumbs-container a:hover,
        .woocommerce .product.product-wrapper .item-description .meta_info a:hover,
        .woocommerce-page .product.product-wrapper .item-description .meta_info a:hover,
        .ftc-wg-meta.item-description .meta_info a:hover,
        .ftc-wg-meta.item-description .meta_info .vc-button.wishlist a:hover,
        .gridlist-toggle a.active,
        .ftc-quickshop-wrapper .owl-nav > div.owl-next:hover,
        .ftc-quickshop-wrapper .owl-nav > div.owl-prev:hover,
        .shortcode-icon .vc_icon_element.vc_icon_element-outer .vc_icon_element-inner.vc_icon_element-color-orange .vc_icon_element-icon,
        .comment-reply-link .icon,
        body table.compare-list tr.remove td > a .remove:hover:before,
        a:focus,
        .cart-list span.price:hover,
        .cart-list span.quantity:hover,
        .vc_toggle_title h4:hover,
        .vc_toggle_title h4:before,
        .blogs article h3.heading-title a:hover,
        h3.product-name >a:hover,
        .breadcrumbs-container,
        .woocommerce ul.cart_list li a:hover,
        .woocommerce ul.product_list_widget li a:hover, 
        .woocommerce .products .product.product-wrapper .item-image .vc-button:hover a:hover,
        .vc_color-orange.vc_message_box-solid,
        span.price,
        .ftc-blogs-widget .post_list_widget .post-title:hover,
        body .woocommerce-message:before,
        .blog article .post-info .entry-title .post-title:hover,
        h3.product-name >a:hover,
        a:hover,
        .ftc-search-by-category .search-button:after,
        .woocommerce .products .product.product-wrapper .item-image .compare a:hover,
        .woocommerce .products .product.product-wrapper .item-image .quickshop a:hover,
        .woocommerce .products .product.product-wrapper .item-image .compare a:hover i:before,
        .woocommerce .products .product.product-wrapper .item-image .quickshop a:hover i:before,
        .woocommerce-info:before,
        .post-info .ftc-team-member a:hover,
        .woocommerce div.product p.stock,
        div.ftc-quickshop-wrapper.product p.stock,
        .woocommerce .widget_layered_nav ul li:hover,
        .woocommerce .widget_layered_nav ul li:hover a,
        .widget-container.ftc-product-categories-widget ul.product-categories li a:hover,
        .lang_sel_click  ul li > a:hover,
        .breadcrumbs .breadcrumbs-container a:hover,
        .breadcrumbs .breadcrumbs-container a:active,
        span.price ins,
        .logo-coming-soon,
        .widget-container ul > li a:hover,
        .woocommerce table.shop_table td a:hover,
        .my-wishlist-wrapper .tini-wishlist a:hover .count-wish,
        .newsletterpopup .close-popup:hover:after,
        .ftc-recent-comments-widget .author:hover,
        .ftc-recent-comments-widget .author:hover a,
        .woocommerce-page .products.list .product h3.product-name a:hover,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li > .item_link:hover:after,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li.current-menu-ancestor > .item_link:after,
        .lang_sel_click ul ul li > a:hover span,
        .cart-list li .cart-item-wrapper a.remove:hover:before,
        .woocommerce .widget_shopping_cart .cart_list li a.remove:hover:before,
        .off-can-vas-inner .woocommerce.widget_shopping_cart .cart_list li a.remove:hover:before,
        body .dokan-pagination-container .dokan-pagination li:not(.active) a:hover,
        .woocommerce .product a:hover span.watch-video,
        .woocommerce-mini-cart .quantity .amount,
        .woocommerce-mini-cart__total .amount,
        .dokan-single-store .profile-frame .profile-info-box
        .profile-info-summery-wrapper .profile-info-summery
        .profile-info .dokan-store-info .dokan-store-phone a:hover,
        .dokan-single-store .profile-frame .profile-info-box
        .profile-info-summery-wrapper .profile-info-summery
        .profile-info .dokan-store-info .dokan-store-email a:hover,
        .profile-info-box .img-social .social-store ul li a:hover,
        .dokan-category-menu #cat-drop-stack > ul li a:hover,
        .contact_info_map .info_contact .info_column ul li a:hover,
        .ftc_search_ajax .search-button:hover, .dropdown-menu-header-wrapper:hover span.fa.fa-cog,
        .ftc-tiny-cart-wrapper:hover .cart-control.cart-item-canvas, .header-language:hover .lang_sel_click ul li > a, .header-currency:hover .wcml_currency_switcher>a, .widget-container.ftc-product-categories-widget ul.product-categories li:hover >span.icon-toggle:before, .widget-container ul > li:hover >span.count,
        aside.widget #cat-drop-stack > ul li a:hover, .widget-container.widget_text h3.active:after,
		body .menu >li >ul >li >a:hover
        {
                color: <?php echo esc_html($ftc_primary_color) ?>;
        }
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li:hover > .item_link,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li > .item_link:hover,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li > .item_link:focus,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li:hover > .item_link *,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li.current-menu-ancestor > .item_link,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li.current-menu-ancestor > .item_link *,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li.current-page-ancestor > .item_link *,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li.current-post-ancestor > .item_link *,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li.current-menu-item > .item_link *,
        #mega_main_menu.primary .mega_dropdown > li.current-menu-item > .item_link *,
        #mega_main_menu.primary .mega_dropdown > li > .item_link:focus *,
        #mega_main_menu.primary .mega_dropdown > li > .item_link:hover *,
        #mega_main_menu.primary li.post_type_dropdown > .mega_dropdown > li > .processed_image:hover > .cover > a > i,
        #mega_main_menu > .menu_holder > .menu_inner > ul > li.current_page_item > a:first-child:after,
        .gridlist-toggle a:hover:before,
        .gridlist-toggle a.active,
        .woocommerce a.remove:hover,
        body table.compare-list tr.remove td > a .remove:hover:before,
           .profile-info-box .img-social .social-store ul li:hover i,
           .profile-info-box .fa-facebook:hover:before,
.profile-info-box .fa-twitter:hover:before,
.profile-info-box .fa-google-plus:hover:before,
.profile-info-box .fa-rss:hover:before
        {
                color: <?php echo esc_html($ftc_primary_color) ?>!important ;
                }
        .dropdown-container .dropdown-footer > a.button.checkout:hover,
        .woocommerce .widget_price_filter .price_slider_amount .button:hover,
        .woocommerce-page .widget_price_filter .price_slider_amount .button:hover,
        body input.wpcf7-submit:hover,
        .woocommerce .products.list .product.product-wrapper .item-description .vc-button a:not(.quickshop):hover,
        .woocommerce .products.list .product.product-wrapper .item-description .vc-button.quickshop i:hover,
        .counter-wrapper > div,
        .tp-bullets .tp-bullet:after,
        .woocommerce .product .product-label .onsale,
        .woocommerce #respond input#submit:hover, 
        .woocommerce a.button:hover,
        .woocommerce button.button:hover, 
        .woocommerce input.button:hover,
        .woocommerce .products .product.product-wrapper .item-image .vc-button:hover a:hover,
        .vc_color-orange.vc_message_box-solid,
        .woocommerce nav.woocommerce-pagination ul li span.current,
        .woocommerce-page nav.woocommerce-pagination ul li span.current,
        .woocommerce nav.woocommerce-pagination ul li a.next:hover,
        .woocommerce-page nav.woocommerce-pagination ul li a.next:hover,
        .woocommerce nav.woocommerce-pagination ul li a.prev:hover,
        .woocommerce-page nav.woocommerce-pagination ul li a.prev:hover,
        .woocommerce nav.woocommerce-pagination ul li a:hover,
        .woocommerce-page nav.woocommerce-pagination ul li a:hover,
        .woocommerce .form-row input.button:hover,
        .load-more-wrapper .button:hover,
        body .vc_general.vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-tab:hover,
        body .vc_general.vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-tab.vc_active,
        .woocommerce div.product form.cart .button:hover,
        .woocommerce div.product div.summary p.cart a:hover,
        div.product .summary .yith-wcwl-add-to-wishlist a:hover,
        .woocommerce #content div.product .summary .compare:hover,
        div.product .social-sharing li a:hover,
        .woocommerce div.product .woocommerce-tabs ul.tabs li.active,
        .tagcloud a:hover,
        .woocommerce .wc-proceed-to-checkout a.button.alt:hover,
        .woocommerce .wc-proceed-to-checkout a.button:hover,
        .woocommerce-cart table.cart input.button:hover,
        .owl-dots > .owl-dot span:hover,
        .owl-dots > .owl-dot.active span,
        footer .style-3 .feedburner-subscription .button.button-secondary.transparent,
        .woocommerce .widget_price_filter .ui-slider .ui-slider-range,
        body .vc_tta.vc_tta-accordion .vc_tta-panel.vc_active .vc_tta-panel-title > a,
        body .vc_tta.vc_tta-accordion .vc_tta-panel .vc_tta-panel-title > a:hover,
        body div.pp_details a.pp_close:hover:before,
        .vc_toggle_title h4:after,
        body.error404 .page-header a,
        body .button.button-secondary,
        .pp_woocommerce div.product form.cart .button,
        .shortcode-icon .vc_icon_element.vc_icon_element-outer .vc_icon_element-inner.vc_icon_element-background-color-orange.vc_icon_element-background,
        .style1 .ftc-countdown .counter-wrapper > div,
        .style2 .ftc-countdown .counter-wrapper > div,
        .style3 .ftc-countdown .counter-wrapper > div,
        #cboxClose:hover,
        body > h1,
        .vc_progress_bar.wpb_content_element > .vc_general.vc_single_bar > .vc_bar,
        div.product.vertical-thumbnail .images-thumbnails .owl-controls div.owl-prev:hover,
        div.product.vertical-thumbnail .images-thumbnails .owl-controls div.owl-next:hover,
        ul > .page-numbers.current,
        ul > .page-numbers:hover,
        article a.button-readmore:hover,
        .woocommerce div.product form.cart .button,
        .woocommerce .product .product-label .featured,
        .woocommerce .products.list .product.product-wrapper .item-description .vc-button a:hover,
        .dropdown-container .dropdown-footer > a.button,
        body > h1:first-child,
        .vc_btn3.vc_btn3-color-purple, .vc_btn3.vc_btn3-color-purple.vc_btn3-style-flat,
        .woocommerce .product .item-image .group-button-image > div:hover, .woocommerce .products .product.product-wrapper .item-image > .button-container > a:hover, 
        .vc_color-orange.vc_message_box-solid,
        .woocommerce .product .item-image .group-button-image > div.yith-wcwl-add-to-wishlist:hover, 
        .woocommerce .product .item-image .group-button-image > a:hover,
        body.wpb-js-composer li.vc_tta-tab.vc_active,
        body .vc_general.vc_tta-tabs .vc_tta-tab .vc_active:active, 
        body .vc_general.vc_tta-tabs .vc_tta-tab:active, 
        body .vc_general.vc_tta-tabs .vc_tta-tab:hover,
        #to-top a,
        .vc_toggle_title h4:before,
        .button-start button,
        #pp_full_res .pp_inline p.cart a:hover,
        body.error404 .back-home,
        body.error404 .page-header a,
        .text_service > div >a,
        body .subscribe_comingsoon .subscribe-email .button.button-secondary:hover,
        .woocommerce div.product div.summary p.cart a,
        .product-thumbnails .owl-nav .owl-prev:hover,
        .product-thumbnails .owl-nav .owl-next:hover,
        .woocommerce .products.list .product.product-wrapper .item-description .add-to-cart a,
        .woocommerce .products.list .product.product-wrapper .item-description div.yith-wcwl-add-to-wishlist a:hover, 
        .woocommerce .products.list .product.product-wrapper .item-description .compare:hover,
        .woocommerce .products.list .product.product-wrapper .item-description .quickshop:hover,
        button,
        input[type="button"],
        input[type="submit"],
        .woocommerce #respond input#submit.alt:hover,
        .woocommerce a.button.alt:hover,
        .woocommerce button.button.alt:hover,
        .woocommerce input.button.alt:hover,
        .commentPaginate .page-numbers:hover,
        .comments-pagination .page-numbers:hover,
        body .page-numbers.current,
        .ftc-mobile-wrapper .menu-text .btn-toggle-canvas.btn-close,
        .header-layout2.header-sticky-mobile,
        .progress-bar,
        .modal-header,
        .modal-footer,
        .cookies-buttons a.btn.btn-size-small.btn-color-primary.cookies-accept-btn,
        .off-can-vas-inner p.woocommerce-mini-cart__buttons.buttons > a.button.wc-forward:hover,
        body .dokan-pagination-container .dokan-pagination li.active a,
         body #dokan-secondary .widget:not(.dokan-category-menu) h3.widget-title, body input[type="submit"].dokan-btn-theme, body a.dokan-btn-theme, body .dokan-btn-theme, body .dokan-pagination-container .dokan-pagination li a:hover, body .dokan-pagination-container .dokan-pagination li.active a, .dokan-single-store .dokan-store-tabs ul li a:hover, .cookies-buttons a,
         body .dokan-category-menu h3.widget-title,
        body #dokan-secondary .widget h3.widget-title,
        .woocommerce #payment #place_order:hover, .woocommerce-page #payment #place_order:hover,
		.footer-bottom .vc_row, .my-account-wrapper .account-control>a
        {
                background-color: <?php echo esc_html($ftc_primary_color) ?>;
        }
         table.compare-list .add-to-cart td a:hover,
         body > h1:first-child,
         body a.dokan-btn-theme:focus,body .dokan-btn-theme:focus,
         .woocommerce #review_form #respond .form-submit input:hover,
         .off-can-vas-inner p.woocommerce-mini-cart__buttons.buttons>a.button.wc-forward.checkout:hover,
         .off-can-vas-inner p.woocommerce-mini-cart__buttons.buttons>a.button.wc-forward:hover
        {
                background-color: <?php echo esc_html($ftc_primary_color) ?> !important;
        }
	   .dropdown-container .dropdown-footer > a.button.view-cart:hover,
        .dropdown-container .dropdown-footer > a.button.checkout:hover,
        .woocommerce .widget_price_filter .price_slider_amount .button:hover,
        .woocommerce-page .widget_price_filter .price_slider_amount .button:hover,
        body input.wpcf7-submit:hover,
        .counter-wrapper > div,
        .woocommerce .products .product:hover .product-wrapper,
        .woocommerce-page .products .product:hover .product-wrapper,
        #right-sidebar .product_list_widget:hover li,
        .woocommerce .product.product-wrapper .item-description .meta_info a:hover,
        .woocommerce-page .product.product-wrapper .item-description .meta_info a:hover,
        .ftc-wg-meta.item-description .meta_info a:hover,
        .ftc-wg-meta.item-description .meta_info .vc-button.wishlist a:hover,
        .woocommerce .products .product:hover .product-wrapper,
        .woocommerce-page .products .product:hover .product-wrapper,
        .ftc-products-category-tabs-block ul.tabs li:hover,
        .ftc-products-category-tabs-block ul.tabs li.current,
        body .vc_tta.vc_tta-accordion .vc_tta-panel.vc_active .vc_tta-panel-title > a,
        body .vc_tta.vc_tta-accordion .vc_tta-panel .vc_tta-panel-title > a:hover,
         body div.pp_details a.pp_close:hover:before,
        .wpcf7 p input:focus,
        .wpcf7 p textarea:focus,
        .woocommerce form .form-row .input-text:focus,
        body .button.button-secondary,
        .ftc-quickshop-wrapper .owl-nav > div.owl-next:hover,
        .ftc-quickshop-wrapper .owl-nav > div.owl-prev:hover,
        #cboxClose:hover, body .woocommerce-error, body .woocommerce-info, body .woocommerce-message,
        #to-top a,
        body .subscribe_comingsoon .subscribe-email .button.button-secondary:hover,
        .woocommerce div.product .woocommerce-tabs ul.tabs li::after,
        .ftc-mobile-wrapper .menu-text .btn-toggle-canvas.btn-close,
        body a.dokan-btn-theme, body .dokan-btn-theme,
        body a.dokan-btn-theme:focus,body .dokan-btn-theme:focus,
        .off-can-vas-inner p.woocommerce-mini-cart__buttons.buttons>a.button.checkout.wc-forward:hover,
        .woocommerce-account .woocommerce-MyAccount-navigation li.is-active
        {
                border-color: <?php echo esc_html($ftc_primary_color) ?>;
        }
        .lang_sel_click ul ul,
        .header-currency ul,
        .ftc-tiny-account-wrapper .dropdown-container,
        .shopping-cart-wrapper .dropdown-container,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li.current_page_item,
        #mega_main_menu > .menu_holder > .menu_inner > ul > li:hover,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li.current-menu-ancestor > .item_link,
        #mega_main_menu > .menu_holder > .menu_inner > ul > li.current_page_item > a:first-child:after,
        #mega_main_menu > .menu_holder > .menu_inner > ul > li > a:first-child:hover:before,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li.current-menu-ancestor > .item_link:before,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li.current_page_item > .item_link:before,
        #mega_main_menu.primary > .menu_holder > .menu_inner > ul > li > .mega_dropdown,
        .woocommerce .product .product-label .onsale:before,
        .woocommerce .product .product-label .featured:before,
        .woocommerce .product .product-label .out-of-stock:before,
        .woocommerce-info, .woocommerce-info::before,
        #ftc-ajax-search-result,
        .header-currency ul:before,
        #dropdown-list
        {
                border-top-color: <?php echo esc_html($ftc_primary_color) ?>;
        }
        .woocommerce .products.list .product:hover .product-wrapper .item-description:after,
        .woocommerce-page .products.list .product:hover .product-wrapper .item-description:after
        {
                border-left-color: <?php echo esc_html($ftc_primary_color) ?>;
        }
        footer#colophon .ftc-footer .widget-title:before,
        .woocommerce div.product .woocommerce-tabs ul.tabs,
        #customer_login h2 span:before,
        .cart_totals  h2 span:before,
        .blog-ftc-wrp,
        .blog-home3 .ftc-blogs article .post-info,
        .blog-v4 .blog-ftc-wrp,
        .blog-v2 .blog-ftc-wrp,
        .single-post article .post-img,
        .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, 
        .woocommerce div.product .woocommerce-tabs ul.tabs li.active, 
        .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, 
        .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, 
        .woocommerce #content div.product .woocommerce-tabs ul.tabs li:hover, 
        .woocommerce div.product .woocommerce-tabs ul.tabs li:hover, 
        .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li:hover, 
        .woocommerce-page div.product .woocommerce-tabs ul.tabs li:hover
        .woocommerce div.product .woocommerce-tabs ul.tabs li.active
        {
                border-bottom-color: <?php echo esc_html($ftc_primary_color) ?>;
        }
        
        /* ========== Secondary color ========== */
        body,
        #mega_main_menu.primary ul li .mega_dropdown > li.sub-style > .item_link .link_text,
        .woocommerce a.remove,
        body.wpb-js-composer .vc_general.vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-tab,
        .woocommerce .products .star-rating.no-rating,
        .woocommerce-page .products .star-rating.no-rating,
        .star-rating.no-rating:before,
        .pp_woocommerce .star-rating.no-rating:before,
        .woocommerce .star-rating.no-rating:before,
        .woocommerce-page .star-rating.no-rating:before,
        .vc_progress_bar .vc_single_bar .vc_label,
        .vc_btn3.vc_btn3-size-sm.vc_btn3-style-outline,
        .vc_btn3.vc_btn3-size-sm.vc_btn3-style-outline-custom,
        .vc_btn3.vc_btn3-size-md.vc_btn3-style-outline,
        .vc_btn3.vc_btn3-size-md.vc_btn3-style-outline-custom,
        .vc_btn3.vc_btn3-size-lg.vc_btn3-style-outline,
        .vc_btn3.vc_btn3-size-lg.vc_btn3-style-outline-custom,
        .style1 .ftc-countdown .counter-wrapper > div .ref-wrapper,
        .style2 .ftc-countdown .counter-wrapper > div .ref-wrapper,
        .style3 .ftc-countdown .counter-wrapper > div .ref-wrapper,
        .style4 .ftc-countdown .counter-wrapper > div .number-wrapper .number,
        .style4 .ftc-countdown .counter-wrapper > div .ref-wrapper,
        body table.compare-list tr.remove td > a .remove:before,
        .woocommerce-page .products.list .product h3.product-name a,
        .blogs article h3.heading-title a ,
        {
                color: <?php echo esc_html($ftc_secondary_color) ?>;
        }
        .dropdown-container .dropdown-footer > a.button.checkout,
        .pp_woocommerce div.product form.cart .button:hover,
        .info-company li i,
        body .button.button-secondary:hover,
        div.pp_default .pp_close, body div.pp_woocommerce.pp_pic_holder .pp_close,
        body div.ftc-product-video.pp_pic_holder .pp_close,
        body .ftc-lightbox.pp_pic_holder a.pp_close,
        #cboxClose
       
        {
                background-color: <?php echo esc_html($ftc_secondary_color) ?>;
        }
        .dropdown-container .dropdown-footer > a.button.checkout,
        .pp_woocommerce div.product form.cart .button:hover,
        body .button.button-secondary:hover,
        #cboxClose
        {
                border-color: <?php echo esc_html($ftc_secondary_color) ?>;
        }
        
        /* ========== Body Background color ========== */
        body
        {
                background-color: <?php echo esc_html($ftc_body_background_color) ?>;
        }
	/* Custom CSS */
	<?php 
	if( !empty($ftc_custom_css_code) ){
		echo html_entity_decode( trim( $ftc_custom_css_code ) );
	}
	?>