<?php 
$options = array();

$options[] = array(
				'id'		=> 'product360'
				,'label'	=> ''
				,'desc'		=> ''
				,'type'		=> 'gallery'
			);
			
?>