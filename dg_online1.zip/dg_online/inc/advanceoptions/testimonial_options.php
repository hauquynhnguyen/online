<?php 
$options = array();

$options[] = array(
				'id'		=> 'gravatar_email'
				,'label'	=> esc_html__('Gravatar Email Address', 'online')
				,'desc'		=> esc_html__('Enter in an e-mail address, to use a Gravatar, instead of using the "Featured Image". You have to remove the "Featured Image".', 'online')
				,'type'		=> 'text'
			);
			
$options[] = array(
				'id'		=> 'byline'
				,'label'	=> esc_html__('Byline', 'online')
				,'desc'		=> esc_html__('Enter a byline for the customer giving this testimonial (for example: "CEO of ThemeFTC").', 'online')
				,'type'		=> 'text'
			);
			
$options[] = array(
				'id'		=> 'url'
				,'label'	=> esc_html__('URL', 'online')
				,'desc'		=> esc_html__('Enter a URL that applies to this customer (for example: http://themeftc.com/).', 'online')
				,'type'		=> 'text'
			);
			
$options[] = array(
				'id'		=> 'rating'
				,'label'	=> esc_html__('Rating', 'online')
				,'desc'		=> ''
				,'type'		=> 'select'
				,'options'	=> array(
						'-1'	=> esc_html__('no rating', 'online')
						,'0'	=> esc_html__('0 star', 'online')
						,'0.5'	=> esc_html__('0.5 star', 'online')
						,'1'	=> esc_html__('1 star', 'online')
						,'1.5'	=> esc_html__('1.5 star', 'online')
						,'2'	=> esc_html__('2 stars', 'online')
						,'2.5'	=> esc_html__('2.5 stars', 'online')
						,'3'	=> esc_html__('3 stars', 'online')
						,'3.5'	=> esc_html__('3.5 stars', 'online')
						,'4'	=> esc_html__('4 stars', 'online')
						,'4.5'	=> esc_html__('4.5 stars', 'online')
						,'5'	=> esc_html__('5 stars', 'online')
				)
			);
?>