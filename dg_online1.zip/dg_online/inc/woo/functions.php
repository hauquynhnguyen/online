<?php
/* * * Tiny account ** */
if (!function_exists('ftc_tiny_account')) {

    function ftc_tiny_account() {
        $login_url = '#';
        $register_url = '#';
        $profile_url = '#';
        $logout_url = wp_logout_url(get_permalink());

        if (ftc_has_woocommerce()) { /* Active woocommerce */
            $myaccount_page_id = get_option('woocommerce_myaccount_page_id');
            if ($myaccount_page_id) {
                $login_url = get_permalink($myaccount_page_id);
                $register_url = $login_url;
                $profile_url = $login_url;
            }
        } else {
            $login_url = wp_login_url();
            $register_url = wp_registration_url();
            $profile_url = admin_url('profile.php');
        }

        $redirect_to = ( is_ssl() ? 'https://' : 'http://' ) . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

        $_user_logged = is_user_logged_in();
        ob_start();
        ?>
        <div class="ftc-tiny-account-wrapper">
            <div class="account-control">
                <?php if (!$_user_logged): ?>
                    <a  class="login" href="<?php echo esc_url($login_url); ?>" title="<?php esc_html_e('Login', 'online'); ?>"><span><?php esc_html_e('Login', 'online'); ?></span></a>
                    / 
                    <a class="sign-up" href="<?php echo esc_url($register_url); ?>" title="<?php esc_html_e('Create New Account', 'online'); ?>"><span><?php esc_html_e('Sign up', 'online'); ?></span></a>
                <?php else: ?>
                    <a class="my-account" href="<?php echo esc_url($profile_url); ?>" title="<?php esc_html_e('My Account', 'online'); ?>"><span><?php esc_html_e('My Account', 'online'); ?></span></a> /
                    <a class="log-out" href="<?php echo esc_url($logout_url); ?>" title="<?php esc_html_e('Logout', 'online'); ?>"><span><?php esc_html_e('Logout', 'online'); ?></span></a>
                <?php endif; ?>
            </div>
            <?php if (!$_user_logged): ?>
                <div class="account-dropdown-form dropdown-container">
                    <div class="form-content">	
                        <form name="ftc-login-form" class="ftc-login-form" action="<?php echo esc_url(wp_login_url()); ?>" method="post">

                            <p class="login-username">
                                <label><?php esc_html_e('Username', 'online'); ?></label>
                                <input type="text" name="log" class="input" value="" size="20" autocomplete="off">
                            </p>
                            <p class="login-password">
                                <label><?php esc_html_e('Password', 'online'); ?></label>
                                <input type="password" name="pwd" class="input" value="" size="20">
                            </p>

                            <p class="login-submit">
                                <input type="submit" name="wp-submit" class="button-secondary button" value="<?php esc_html_e('Login', 'online'); ?>">
                                <input type="hidden" name="redirect_to" value="<?php echo esc_url($redirect_to); ?>">
                            </p>

                        </form>

                        <p class="forgot-pass"><a href="<?php echo esc_url(wp_lostpassword_url()); ?>" title="<?php esc_html_e('Forgot Your Password?', 'online'); ?>"><?php esc_html_e('Forgot Your Password?', 'online'); ?></a></p>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <?php
        return ob_get_clean();
    }

}

/* * * Tiny Cart ** */
if (!function_exists('ftc_tiny_cart')) {

    function ftc_tiny_cart() {
        if (!ftc_has_woocommerce()) {
            return '';
        }
        global $smof_data;
        $cart_empty = WC()->cart->is_empty();
        $cart_url = wc_get_cart_url(); // since 2.5.0 use wc_get_cart_url();
        $checkout_url = wc_get_checkout_url(); // since 2.5.0 use wc_get_checkout_url();
        $cart_number = WC()->cart->get_cart_contents_count();
        ob_start();
        ?>
        <div class="ftc-tiny-cart-wrapper">
            <a class="cart-control <?php if(isset($smof_data['ftc_cart_layout']) && $smof_data['ftc_cart_layout'] == 'off-canvas') {
                        echo "cart-item-canvas";
                    } ?>" href="<?php echo esc_url($cart_url); ?>" title="<?php esc_html_e('View your shopping bag', 'online'); ?>">
                <p class="cart-number ">
            <?php 
            if ($cart_number > 1) {
                echo esc_html($cart_number);
            } else {
                echo esc_html($cart_number);
            }
            ?></p>
            </a>
            <?php if(isset($smof_data['ftc_cart_layout']) && $smof_data['ftc_cart_layout'] == 'dropdown'): ?>
            <div class="cart-dropdown-form dropdown-container">
                <div class="form-content">
                        <?php if ($cart_empty): ?>
                        <label><?php esc_html_e('Your shopping cart is empty', 'online'); ?></label>
                                <?php else: ?>
                        <ul class="cart-list">
            <?php
            $cart = WC()->cart->get_cart();
            foreach ($cart as $cart_item_key => $cart_item):
                $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                if (!( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key) )) {
                    continue;
                }

                $product_price = apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key);
                ?>
                                <li>
                                    <a href="<?php echo get_permalink($cart_item['product_id']); ?>">
                                <?php echo $_product->get_image(); ?>
                                    </a>
                                    <div class="cart-item-wrapper">	
                                        <h3 class="product-name">
                                            <a href="<?php echo get_permalink($cart_item['product_id']); ?>">
                <?php echo $_product->get_title(); ?>
                                            </a>
                                        </h3>
                            <?php echo apply_filters('woocommerce_widget_cart_item_quantity', '<span class="quantity">' . $cart_item['quantity'] . '</span> ', $cart_item, $cart_item_key); ?>
                            <?php echo apply_filters('woocommerce_widget_cart_item_quantity', '<span class="price"><span class="amount icon"> x </span> ' . $product_price . '</span>', $cart_item, $cart_item_key); ?>
                <?php echo apply_filters('woocommerce_cart_item_remove_link', sprintf('<a href="%s" class="remove" title="%s" data-key="%s">&times;</a>', esc_url(wc_get_cart_remove_url($cart_item_key)), esc_html__('Remove this item', 'online'), $cart_item_key), $cart_item_key); ?>
                                    </div>
                                </li>

            <?php endforeach; ?>
                        </ul>
                        <div class="dropdown-footer">
                            <div class="total"><span class="total-title"><?php esc_html_e('Subtotal :', 'online'); ?></span><?php echo WC()->cart->get_cart_subtotal(); ?> </div>

                            <a href="<?php echo esc_url($cart_url); ?>" class="button view-cart"><?php esc_html_e('View cart', 'online'); ?></a>
                            <a href="<?php echo esc_url($checkout_url); ?>" class="button checkout button-secondary"><?php esc_html_e('Checkout', 'online'); ?></a>
                        </div>
                <?php endif; ?>
            </div>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

}
add_action('wp_footer', 'ftc_canvas_cart');
function ftc_canvas_cart(){
    if (!ftc_has_woocommerce()) {
        return '';
    }
    global $smof_data;
    ?>
    <?php if(isset($smof_data['ftc_cart_layout']) && $smof_data['ftc_cart_layout'] == 'off-canvas'): ?>
        <div class="ftc-off-canvas-cart">
            <div class="off-canvas-cart-title">
                <div class="title"><?php esc_html_e('Shopping Cart', 'online'); ?></div>
                <a href="#" class="close-cart"> <?php esc_html_e('Close', 'online') ?></a>
            </div>
            <div class="off-can-vas-inner">
                <div class="woocommerce widget_shopping_cart">
                    <div class="widget_shopping_cart_content">
                        <?php echo woocommerce_mini_cart(); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php

}
add_filter('woocommerce_add_to_cart_fragments', 'ftc_tiny_cart_filter');

function ftc_tiny_cart_filter($fragments) {
    $fragments['.ftc-tiny-cart-wrapper'] = ftc_tiny_cart();
    return $fragments;
}

function ftc_remove_cart_item() {
    $cart_item_key = sanitize_text_field($_POST['cart_item_key']);
    if ($cart_item = WC()->cart->get_cart_item($cart_item_key)) {
        WC()->cart->remove_cart_item($cart_item_key);
    }
    WC_AJAX::get_refreshed_fragments();
}

add_action('wp_ajax_ftc_remove_cart_item', 'ftc_remove_cart_item');
add_action('wp_ajax_nopriv_ftc_remove_cart_item', 'ftc_remove_cart_item');

add_filter('woocommerce_add_to_cart_fragments', 'ftc_cart_filter');
    function ftc_cart_filter($fragments) {
    ob_start();
    ftc_cart_subtotal();
    $subtotal = ob_get_clean();
    $fragments['span.footer-cart-number'] = $subtotal;

    return $fragments;
}

if( ! function_exists( 'ftc_cart_subtotal' ) ) {
    function ftc_cart_subtotal() {
        ?>
        <span class="footer-cart-number"> <?php echo "(". WC()->cart->get_cart_contents_count().  ")"?></span>
        <?php
    }
}
/** Tini wishlist * */
function ftc_tini_wishlist() {
    if (!(ftc_has_woocommerce() && class_exists('YITH_WCWL'))) {
        return;
    }

    ob_start();

    $wishlist_page_id = get_option('yith_wcwl_wishlist_page_id');
    if (function_exists('wpml_object_id_filter')) {
        $wishlist_page_id = wpml_object_id_filter($wishlist_page_id, 'page', true);
    }
    $wishlist_page = get_permalink($wishlist_page_id);

    $count = yith_wcwl_count_products();
    ?>

    <a title="<?php esc_html_e('Wishlist', 'online'); ?>" href="<?php echo esc_url($wishlist_page); ?>" class="tini-wishlist">
    <i class="fa fa-heart"></i> 
    <?php esc_html_e('Wishlist', 'online'); ?> <span class="count-wish"><?php echo '(' . ($count > 0 ? zeroise($count, 1) : '0') . ')'; ?></span>
    </a>

    <?php
    $tini_wishlist = ob_get_clean();
    return $tini_wishlist;
}

function ftc_update_tini_wishlist() {
    die(ftc_tini_wishlist());
}

add_action('wp_ajax_update_tini_wishlist', 'ftc_update_tini_wishlist');
add_action('wp_ajax_nopriv_update_tini_wishlist', 'ftc_update_tini_wishlist');

if (!function_exists('ftc_woocommerce_multilingual_currency_switcher')) {

    function ftc_woocommerce_multilingual_currency_switcher() {
        if (class_exists('woocommerce_wpml') && class_exists('WooCommerce') && class_exists('SitePress')) {
            global $sitepress, $woocommerce_wpml;

            if (!isset($woocommerce_wpml->multi_currency)) {
                return;
            }

            $settings = $woocommerce_wpml->get_settings();

            $format = isset($settings['wcml_curr_template']) && $settings['wcml_curr_template'] != '' ? $settings['wcml_curr_template'] : '%code%';
            $wc_currencies = get_woocommerce_currencies();
            if (!isset($settings['currencies_order'])) {
                $currencies = $woocommerce_wpml->multi_currency->get_currency_codes();
            } else {
                $currencies = $settings['currencies_order'];
            }

            $selected_html = '';
            foreach ($currencies as $currency) {
                if ($woocommerce_wpml->settings['currency_options'][$currency]['languages'][$sitepress->get_current_language()] == 1) {
                    $currency_format = preg_replace(array('#%name%#', '#%symbol%#', '#%code%#'), array($wc_currencies[$currency], get_woocommerce_currency_symbol($currency), $currency), $format);

                    if ($currency == $woocommerce_wpml->multi_currency->get_client_currency()) {
                        $selected_html = '<a href="javascript: void(0)" class="wcml_selected_currency">' . $currency_format . '</a>';
                        break;
                    }
                }
            }

            echo '<div class="wcml_currency_switcher">';
            echo $selected_html;
            echo '<ul>';

            foreach ($currencies as $currency) {
                if ($woocommerce_wpml->settings['currency_options'][$currency]['languages'][$sitepress->get_current_language()] == 1) {
                    $currency_format = preg_replace(array('#%name%#', '#%symbol%#', '#%code%#'), array($wc_currencies[$currency], get_woocommerce_currency_symbol($currency), $currency), $format);
                    echo '<li rel="' . $currency . '" >' . $currency_format . '</li>';
                }
            }

            echo '</ul>';
            echo '</div>';
        } else if (class_exists('WOOCS') && class_exists('WooCommerce')) { /* Support WooCommerce Currency Switcher */
            global $WOOCS;
            $currencies = $WOOCS->get_currencies();
            if (!is_array($currencies)) {
                return;
            }
            ?>
            <div class="wcml_currency_switcher">
                <a href="javascript: void(0)" class="wcml_selected_currency"><?php echo esc_html($WOOCS->current_currency); ?></a>
                <ul>
            <?php
            foreach ($currencies as $key => $currency) {
                $link = add_query_arg('currency', $currency['name']);
                echo '<li rel="' . $currency['name'] . '"><a href="' . esc_url($link) . '">' . esc_html($currency['name']) . '</a></li>';
            }
            ?>
                </ul>
            </div>
            <?php
        } else {/* Demo html */
            ?>
            <div class="wcml_currency_switcher">
                <a href="javascript: void(0)" class="wcml_selected_currency">USD</a>
                <ul>
                    <li rel="USD">Dollar (USD)</li>
                    <li rel="EUR">Euro (EUR)</li>
                </ul>
            </div>
            <?php
        }
    }

}

if( !function_exists('ftc_wpml_language_selector') ){
    function ftc_wpml_language_selector(){
        if ( function_exists( 'icl_get_languages' ) ) {
         $languages = icl_get_languages(); 
            if(!empty($languages)){
                                foreach($languages as $language){
                                    if ($language['language_code'] == ICL_LANGUAGE_CODE) {
                                    ?>
                            <div class="current-language" href="<?php echo $language['url']; ?>">
                            <img src="<?php echo $language['country_flag_url']; ?>">
                            <?php echo $language['native_name']; ?></div>
                                <?php
                                    }
                                }
            }
            ?>
            <ul>
                <?php foreach ( $languages as $lang ) : ?>
                    <li<?php if ( $lang['active'] ) : ?> class="active"<?php endif; ?>>
                        <a href="<?php echo $lang['url']; ?>">
                            <img src="<?php echo $lang['country_flag_url']; ?>">
                            <?php echo $lang['native_name']; ?></a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php }
        else{ /* Demo html */
            ?>
            <div class="lang_sel_click">
                <ul>
                    <li>
                        <a href="#" class="lang_sel_sel icl-en">EN</a>
                        <ul class="call" style="visibility: hidden;">
                            <li class="icl-fr"><a rel="alternate" href="#"><span class="icl_lang_sel_native">French</span></a></li>
                            <li class="icl-de"><a rel="alternate" href="#"><span class="icl_lang_sel_native">German</span></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <?php
        }
    }
}

?>
