<?php
/**
 * Plugin Name:          WC Vendors Marketplace
 * Plugin URI:           https://www.wcvendors.com
 * Description:          Create a marketplace with WooCommerce and allow vendors to sell their own products and receive a commission for each sale.
 * Author:               WC Vendors
 * Author URI:           https://www.wcvendors.com
 * GitHub Plugin URI:    https://github.com/wcvendors/wcvendors
 *
 * Version:              2.0.10
 * Requires at least:    4.4.0
 * Tested up to:         4.9.5
 * WC requires at least: 3.3.0
 * WC tested up to: 	 3.4.3
 *
 * Text Domain:         wc-vendors
 * Domain Path:         /languages/
 *
 * @category            Plugin
 * @copyright           Copyright © 2012 Matt Gates
 * @copyright           Copyright © 2018 WC Vendors
 * @author              Matt Gates, WC Vendors
 * @package             WCVendors
 * @license     		GPL2

WC Vendors Marketplace is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.

WC Vendors Marketplace is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with WC Vendors Marketplace. If not, see http://www.gnu.org/licenses/gpl-2.0.txt.

*/


/**
 *   Plugin activation hook
 */
		require_once get_template_directory() . '/classes/front/class-vendor-shop.php';